#!/bin/bash
HOME=$(pwd)
cd $HOME/message-sys/priv/

cd addleness
cd pass
echo "$6$/gDoqCFIni4hdevD$TdD35OXYWJtGzmdwWyC0fuWFTTgzA7kGWyIL8J8B3r2/bk91p1zNSiD9cIuBPhN8lofDxNHPFHurXuZoziViQ." >> addleness-hash.txt
#echo "Cardin_pwns" >> addleness-pass.txt
cd ..
cd ..

cd analects
cd pass
echo "$6$b.SJO74iMxa9fGQj$A.pFcuZyKu2YnNQTY1jtcOVTVkAhIkgcgPoZKj873a4dQwQIcgYx4DJ8gTXgrAu3n0VUElVM.5rVNY84A33ce0" >> analects-hash.txt
#echo "pickerel_symbiosis" >> analects-pass.txt
cd ..
cd ..

cd annalistic 
cd pass
echo "$6$CD4vielvTcBIfPEE$nZ5jBA8qfYNwGrcldlUeUwmLrA3B.5TdFMJ.zdivWqYmqaKxbajO/jeCAY1rbNsRLoimJp5I8406RM3qjKxdl/" >> annalistic-hash.txt
#echo "thickets_pimping" >> annalistic-pass.txt
cd ..
cd ..

cd anthropomorphologically 
cd pass
echo "$6$vThaptecyPl43G7v$Fzr6OMFucoVAhUgF1/JcxKnHKeoO/snPx1FCySCuuS7PsMFnedsx5sbmMjIDO9IZq0kLxk1LT2bgxytEcxqRG." >> anthropomorphologically-hash.txt
#echo "likelihoods_hoarsely" >> anthropomorphologically-pass.txt
cd ..
cd ..

cd blepharosphincterectomy 
cd pass
echo "$6$XXQ7JirAVBwV8zSc$9NVxuUGwsUg6qdslSFIuQhhDjLfBcLysoiD01iDq4nXrtUgZkm8bH7Hwyp0MQYzdn/q9lnd1uBiF.8klVefX51" >> blepharosphincterectomy-hash.txt
#echo "plagued_teletypewriter" >> blepharosphincterectomy-pass.txt
cd ..
cd ..

cd corector 
cd pass
echo "$6$fAwROqCdd0.52.8j$83Xv0ilBIT4ApBUtFmUz.Gz2IFHMfYIgAegj8v.QaiFomQzefECXbt3KgRJEF.8rFsM7uoNTSIACyqty/qPlV0" >> corector-hash.txt
#echo "quadruplet_strawed" >> corector-pass.txt
cd ..
cd ..

cd durwaun 
cd pass
echo "$6$NdFVktNQKXzHLMcy$CehSb1gwd6oAQhDLv6mT0TnnWucOsvZhgmKlKPtjuNtdpZWX3VwlXIhcTG92V3EAApNRErlyyYjySRTAuWrhG0" >> durwaun-hash.txt
#echo "hamlet_laudably" >> durwaun-pass.txt
cd ..
cd ..

cd dysphasia 
cd pass
echo "$6$ijotJff81rgiOk4i$pqTdRL3jNS4JJ3aVW3dm4x1i9qSAnMbY1kQPPo1EE3b6h8UzamWudYCGiZbPGrqZSyj0swNTBMmErSlzFv7nq/" >> dysphasia-hash.txt
#echo "equably_undies" >> dysphasia-pass.txt
cd ..
cd ..

cd encampment 
cd pass
echo "$6$/w8WVEWKg.TABxIH$6YvGvwjhP9EGh/C.c9bSw./lPT74Bk7m61a1q4ghUQ1rQ.GY/ReoThkrziGG2byi3cNTUhxGMx.1Ip4c.JU8f/" >> encampment-hash.txt
#echo "Noxzema's_wordiness" >> encampment-pass.txt
cd ..
cd ..

cd endoscopic 
cd pass
echo "$6$1AUtCfSJXYtFArVa$Xl3wmKEp4As2Iwe0Wy1P2mht36wG2WTxqX1feBCryfqHjuY1F1D/OkGb3HkHCgNhAafqNKUgEulWVtX2OJBY1/" >> endoscopic-hash.txt
#echo "centennial's_subplots" >> endoscopic-pass.txt
cd ..
cd ..

cd exilic 
cd pass
echo "$6$KVvPUN/VdM083UzA$7SJt4x2nYqGDHhQubox1xekbaGb3HsCHbUT9MR.OXSsHpQP6Wapr4XN23pAUHThe1jB4gYBbAT9bRnEU9pLw.0" >> exilic-hash.txt
#echo "service_barbing" >> exilic-pass.txt
cd ..
cd ..

cd forfend 
cd pass
echo "$6$feR/JdnzlGpTBIlP$DgZuaMmD6EJWcjmEolGx0qRI1f1H49/U6Ys8VhNGAkNy7fv4Vz3jMDx5lk1rUJYsnySfuWTEKPixDeUAyvIE71" >> forfend-hash.txt
#echo "Tammy's_hoofed" >> forfend-pass.txt
cd ..
cd ..

cd gorbellied 
cd pass
echo "$6$KFn7GsXZfmZIdSLX$lhxZCFGpTg/GPF01Y5sGLFkMz2F3PQ8L3KkDjFKCPuRmCghEOp06GDbKXY.t4IfEnAb2duypOp4uueDNaAjht0" >> gorbellied-hash.txt
#echo "pinfeathers_Finnbogadottir's" >> gorbellied-pass.txt
cd ..
cd ..

cd gushiness 
cd pass
echo "$6$OMH8pweJ0poepMOI$M7Pli2wl/4CGNSzQQjmh11oXpWmT1cVaB/iMSNfepfKPlz945p8L2tFhwb4AC0LXzVxZw0IMyMYpJmy3BaneN." >> gushiness-hash.txt
#echo "Cameroon's_adaptations" >> gusiness-pass.txt
cd ..
cd ..

cd muermo 
cd pass
echo "$6$4TC4JkkwaPLVbW9a$VGiIbCBnUCLgV45.lYX5cGF3TPgKRoa8.zBxyyLd.YeiTnEyNbSGbO1QhKck2/JmWcOB8QrpxlPamKjdB68P.0" >> muermo-hash.txt
#echo "grovelling_turtle" >> muermo-pass.txt
cd ..
cd ..

cd neckar 
cd pass
echo "$6$SsWpuRIUvnqnGsTI$BvUHqonFK1IL2GWNpKv482hOkGYB5r9wvmZs6iixyPQYYl7LoLv1F/HHLP1iON7Z4disxyzWEybl0Dqzo.o3q1" >> neckar-hash.txt
#echo "simmering_Caucasian's" >> neckar-pass.txt
cd ..
cd ..

cd outmate 
cd pass
echo "$6$5IN9HsoMGQ4/btHp$gbsU37IigNh4JS0.ZSPcSJC1FkkYmMtN..DycZkVGmDU/Mq9Rq16GEC.p.smtF8VUe8MeJoXRNhUjvhjv47rB." >> outmate-hash.txt
#echo "gush's_Colombia" >> outmate-pass.txt
cd ..
cd ..

cd outroll 
cd pass
echo "$6$u7BO65b8DcNiUTgy$9fB5aj4dfaIh.seLl1IuSGZFx0McbnrlZITUj76wm55vSesu3.v7nAzU2EcJs8YNjYsPaVj171wFs1gO9N4ns1" >> outroll-hash.txt
#echo "carpus's_hazardous" >> outroll-pass.txt
cd ..
cd ..

cd overrich 
cd pass
echo "$6$dhLq/0a8aa9YTWYh$7ua9ptParx6IAgys4xslDukmnlws7QXMMsq.SVn6PhjGRhnRjGw0gG3eqe668/tgtpt70710f6c1b2w.zzCwD0" >> overrich-hash.txt
#echo "Freemasonry_bruskest" >> overrich-pass.txt
cd ..
cd ..

cd philosophicotheological 
cd pass
echo "$6$HoRF4oMm6c/dABwD$hKfCh2bMAfP3RFL.4LsiKnZ67gXGWRwcGe85mj4OjETn5C7jbTmjFU2t3muIan2x7EpywdcNeY6xmsSx/o6/U1" >> philosophicotheological-hash.txt
#echo "lopsided_garishly" >> philosophicotheological-pass.txt
cd ..
cd ..

cd pockwood 
cd pass
echo "$6$hxfhPTE522CGn7qS$fzmiOIcBA8WilwOFjW8Ijtnf4ZHVTK2cXfH0D4kM3vNsdO15bVVD0Nu3J3HdZ9IHEC.xvIWpv/3ewUU0JAzFw." >> pockwood-hash.txt
#echo "Borges's_helpful" >> pockwood-pass.txt
cd ..
cd ..

cd polypose 
cd pass
echo "$6$mojxgG.mliBuOu8B$yZqwF2jVIDiA8iddJd1OGz5HGdUnSunUDc/t/tjJ3OAd9fzfzqrxnaYH8ZA5kmpJprDcyhUy3Zvj5Py0FjG3L/" >> polypose-hash.txt
#echo "lure_leagued" >> polypose-pass.txt
cd ..
cd ..

cd refluxed 
cd pass
echo "$6$JmkIF2hD1AAdpurb$bI2vMNM7uPH3fl/yH1y0quPUTdfY8Z3QL0G5KN/6li8p9ERnBbTWtm7JrIB/neAsrUp11YRWTMwp3yxRgUyvH1" >> refluxed-hash.txt
#echo "brushed_volubly" >> refluxed-pass.txt
cd ..
cd ..

cd reinsure 
cd pass
echo "$6$XlDr45qHpafZpVpY$P50wADnTexy9jf6Qwavu8e9vIsrU8FJD7.S0XYDOtDhDxbQYP6vvvEoJ4CC5hRCtovFPkYv.gC6pwqj.gvYoN0" >> reinsure-hash.txt
#echo "Hammett_Biden's" >> reinsure-pass.txt
cd ..
cd ..

cd repine 
cd pass
echo "$6$qcb02GwEfdFf0fAy$hzYVgIpM1MbcOeqszKyuDzBs3rWs.7GtsgMWEx80Gb06JscI7PKZegw5sGSHC9R8dxXEEio9EphMprM0PoZCw0" >> repine-hash.txt
#echo "tallyho's_courage" >> repine-pass.txt
cd ..
cd ..

cd scerne 
cd pass
echo "$6$CmdXPs5jInSOrjOn$XjN8Zt57xqAHu6IuPIVz1z8RYqur4hEl2IHifF4tb5ZsFIz3nfwwRva7ELsb8N3yMmhedrgW7FwihZbuuhDo20" >> scerne-hash.txt
#echo "fucks_allured" >> scerne-pass.txt
cd ..
cd ..

cd starshine 
cd pass
echo "$6$y5anj6vXMVDoGsRp$gXTX9MYpmZDw025roL5RK09nfyFkssBQQFEalA/tKjmHMRMdu.ZabV4NhE5iWNc.6T.7jJ/9ccgGHbllGNH.T1" >> starshine-hash.txt
#echo "soul's_blondes" >> starshine-pass.txt
cd ..
cd ..

cd unauthoritativeness 
cd pass
echo "$6$gt5nn/bllrTIGKPO$gMWrFSAq5TWUkFuoISMTSw34aibop6GKp7sX.q.4qMKauU.8uPFcMV/2uTPKkf7HZuuOYTbHuX2iRGjph3iQS0" >> unauthoritativeness-hash.txt
#echo "officially_watershed" >> unauthoritativeness-pass.txt
cd ..
cd ..

cd unminced 
cd pass
echo "$6$Wq9mPbwzid/WJ/0B$yc6wypk.wr1DHK/80klNqz3egoviwbYmVvoj99ubp3nGEvl6Ucd6WyYHlOIi/2mG3bWFwnztCWRMDgfX7.Qh4/" >> unminced-hash.txt
#echo "cleaves_refund" >> unminced-pass.txt
cd ..
cd ..

cd unrosed 
cd pass
echo "$6$hEIaXLhlDQwGpS69$0XvdO2ni85R49XWeY07kH.aYNSA6Ujf9Ux9uFWXWz9VLKUCCxbX5ItUy/1ybWykzooKIMou/gJgTY8KGVVYon." >> unrosed-hash.txt
#echo "shamed_Dow" >> unrosed-pass.txt
cd ..
cd ..

cd untranquil 
cd pass
echo "$6$m7UUpOvQpGIOkjkb$lO0exDNO8ozxpckZ/ST94L.38cJ/vzcN.VVbPeAquc28XpJIcrrZP3oyjDXwYfyu5ahRhzFJfNpszmVtjBtdX/" >> untranquil-hash.txt
#echo "bespoke_supplants" >> untranquil-pass.txt
cd ..
cd ..

cd urushinic 
cd pass
echo "$6$v6ekEDKYazTMcm/P$DyuxOsMKvT.1WMopbpUqZOVHw9Ow5ibXWfLMVwpaQ60S61kaVlOs2jtDYoSpjwmmyrL3F56RCG6MIr.N7nipL/" >> urushinic-hash.txt
#echo "ramble_tiller's" >> urushinic-pass.txt
cd ..
cd ..

cd vegetocarbonaceous 
cd pass
echo "$6$EZetxetCibLSITyh$ztbf64nYfzl91nywTdSoHRjYZUUCt6XFwudGziNglMVWOjUz5m8zlmudwL3Rh.nsWzJ87hVDqt/FjbeniZUqA." >> vegetocarbonaceous-hash.txt
#echo "channelled_inexpressible" >> vegetocarbonaceous-pass.txt
cd ..
cd ..

cd wamara 
cd pass
echo "$6$trls1b6RKKEfxhpG$LqbCbf5ewbuqMIWSumT3Bmo.8De0tjGIn3Nq2EU7OJ5.luyjrYsHY7DsoonEziPt.qXmTalSqEomkVz8Iq9cb0" >> wamara-hash.txt
#echo "stirrer_hewer's" >> wamara-pass.txt
cd ..
cd ..

cd whaledom 
cd pass
echo "$6$SWzP7VHvabtUF0IO$JC28I6mE5Ir8UVGi./pbaOFzrmKl5orir4NV/2e/nq2pIgh2ZVUfQsY4IcOCTJethQaF5BVIjgNugtc2xBKrU/" >> whaledom-hash.txt
#echo "petering_sounding's" >> whaledom-pass.txt
cd ..
cd ..

# sudo chmod -R 600 *
cd ..
# sudo chown -R $SUDO_USER priv

chmod 700 $(find $HOME/message-sys/priv -type d)
chmod 600 $(find $HOME/message-sys/priv -type f)
