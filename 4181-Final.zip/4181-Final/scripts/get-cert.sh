#!/bin/bash

usr=$1

FILE = "/ca/intermediate/certs/$1.cert.pem"
