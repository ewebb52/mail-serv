#!/bin/bash
sudo apt-get update
sudo apt-get install libssl-dev
sudo apt-get install expect